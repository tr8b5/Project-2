# Club Social

## What is Club Social about?
Club Social is an anonymous social media platform where users can post about their experiences in school. We help diversify and implement our technology and api's in order for users to get to choose the school and subject about their experience.

Club Social helps keep everything anonymous and provides a plethora of categories in which other users can take input and use to help them choose a college or be wary about some down sides.

On the flip side, Club Social also helps with providing the good as well that can help steer users into preferring one school over the other.

## Usage

## Credits
collaborators:

William Miller  : https://github.com/tr8b5
Ikenna Nwagbara : https://github.com/ItsJustIkenna
Mya Todd        : https://github.com/mt428376
Rafael Chavez   : https://github.com/Rafael-Chavez

## License

MIT License

Copyright (c) [2021] [William Miller, Ikenna Nwagbara, Mya Todd, Rafael Chavez]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Badges

![Bulma](https://bulma.io/images/made-with-bulma.png)

## Features

Choosing a plethora of schools
Choosing a variety of subjects
Clean interface