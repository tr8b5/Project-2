-- Drops the clubSocial if it exists currently --
DROP DATABASE IF EXISTS clubSocial_db;
-- Creates the "clubSocial" database --
CREATE DATABASE clubSocial_db;
